package handler

import (
	"time"
)

func (h *Handler) UpdateContractConfigs() {
	time.Sleep(time.Second * 60)
}
