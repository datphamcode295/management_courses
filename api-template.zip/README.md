# Backend

```
1. create .env file from .env.example
2. make init
3. make migrate
3. make run
4. make indexer
```
